#!/usr/bin/env python
#-*- coding: utf-8 -*-
"""
@version: ??
@author: Ganker
@software: PyCharm
@file: QiuShiBaiKe.py
@time: 2016/4/30 上午 11:09
"""
import urllib
import urllib2
import re


class QiuBai:
    def __init__(self):
        self.PageIndex = 1
        self.Page = 0
        self.user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
        self.headers = {'User-Agent' : 'self.user_agent'}
        self.enable = False
        self.Jump_en = False
        self.stories = []

    #获取页面信息
    def GetPage(self, PageIndex):
        try:
            url = 'http://www.qiushibaike.com/hot/page/' + str(PageIndex)
            request = urllib2.Request(url, headers=self.headers)
            reponse = urllib2.urlopen(request)
            PageCode = reponse.read().decode('utf-8')
            return PageCode
        except urllib2.URLError, e:
            if hasattr(e, 'reason'):
                print u'链接糗事百科失败，错误原因：', e.reason
                return None

    #对页面信息正则匹配筛选
    def GetPageItems(self, PageIndex):
        PageCode = self.GetPage(PageIndex)
        if not PageCode:
            print u'页面加载失败....'
            return None
        pattern = re.compile('<div.*?author clearfix">.*?<img src="(.*?)".*?alt="(.*?)"/>.*?content">(.*?)</div>.*?number">(\d+)</i>', re.S)
        items = re.findall(pattern, PageCode)
        PageStories = []
        for item in items:
            haveImg = re.search('img', item[0])
            if not haveImg:
                replaceBR = re.compile('<br/>')
                new_item2 = re.sub(replaceBR, '\n', item[2])
                PageStories.append([item[0].strip(), item[1].strip(), new_item2.strip(), item[3].strip()])
        return PageStories

    #加载新的页面
    def LoadPage(self):
        if self.enable == True:
            if len(self.stories) < 2:
                PageStories = self.GetPageItems(self.PageIndex)
                if PageStories:
                    self.stories.append(PageStories)
                    self.PageIndex += 1
            if self.Jump_en == True:
                PageStories = self.GetPageItems(self.Page)
                self.PageIndex = self.Page
                self.Jump_en = False
                if PageStories:
                    self.stories = []
                    self.stories.append(PageStories)
                    self.PageIndex += 1

    #保存当前糗百段子
    def SaveStory(self, OneStory):
        if OneStory:
            file = open("./QiuBai.txt", 'a+')
            OneStory = OneStory.encode('GBK')
            file.write(OneStory)
            file.write('\n\n')
            file.close()


    #每次敲回车，打印一个段子
    def GetOneStory(self, PageStories, Page):
        content = None
        for story in PageStories:
            Save_content = content
            input = raw_input()
            self.LoadPage()
            PageNum = re.compile(r'\d+')
            match = re.search(PageNum, input)
            if (input == 'Q' or input == 'q'):
                self.enable = False
                return
            if (input == 's' or input == 'S'):
                self.SaveStory(Save_content)
            if match:
                self.Jump_en = True
                self.Page = int(match.group())
                break
            content =  u'第%d页\t发布人:%s\t赞:%s\n%s\n图片链接:%s'%(Page, story[1], story[3], story[2], story[0])
            print content

    #开始
    def start(self):
        print u'正在读糗事百科，按回车查看新段子。'
        print u"按'Q' or 'q'退出。"
        print u"按'S' or 's'保存(保存路路径为当前文件夹)。"
        print u'输入数字可以跳转页面。'
        self.enable = True
        self.LoadPage()
        nowPage = 0
        while self.enable:
            if len(self.stories) > 0:
                PageStories = self.stories[0]
                del self.stories[0]
                if self.Jump_en == False:
                    nowPage += 1
                else:
                    nowPage = self.Page
                self.GetOneStory(PageStories, nowPage)


if __name__ == '__main__':
    PageNext = QiuBai()
    PageNext.start()



































